@extends('layouts.master')
@section('content')
    @include('slider')
    <div class="container background-grey bottom-border">
        @include('admin.pages.page_body')
    </div>
@endsection