@extends('frontend_master')
@section('content')
    @include('sample_layout.slider')
    @include('sample_layout.page')
    <!-- Portfolio -->
    @include('sample_layout.products')
@endsection