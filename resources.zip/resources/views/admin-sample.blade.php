@extends('admin_layouts.master')
@section('content')
    <h1> Hello Sample</h1>
@endsection