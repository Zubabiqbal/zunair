<div class="bottom-border-shadow">
    <div class="container background-white bottom-border animate fadeIn">
        @include('admin.pages.page_body')
    </div>
</div>
