<div id="pre-header" class="background-gray-lighter">
    <div class="container no-padding">
        <div class="row hidden-xs">
            <div class="col-sm-6 padding-vert-5">
                <strong>Phone:</strong>&nbsp;1-800-123-4567
            </div>
            <div class="col-sm-6 text-right padding-vert-5">
                <strong>Email:</strong>&nbsp;info@joomla51.com
            </div>
        </div>
    </div>
</div>
   