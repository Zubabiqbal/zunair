<div id="header">
    <div class="container">
        <div class="row">
            <!-- Logo -->
            <div class="logo">
                <a href="{{ url('/') }}" title="">
                    <img src="{{ url('assets/img/logo.png') }}" alt="Logo" />
                </a>
            </div>
            <!-- End Logo -->
        </div>
    </div>
</div>