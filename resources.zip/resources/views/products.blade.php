@extends('frontend_master')
@section('content')
    @include('sample_layout.products')
@endsection