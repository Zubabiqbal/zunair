@extends('admin_layouts.master')
@section('content')
    @include('admin.categories.form')
@endsection