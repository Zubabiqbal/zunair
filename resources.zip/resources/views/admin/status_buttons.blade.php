<div class="btn-group" data-toggle="buttons">
    <label class="btn btn-primary active">
        <input checked="checked" type="radio" name="status" value="1">
        Active
    </label>
    <label class="btn btn-primary">
        <input type="radio" name="status" value="0"> In-active
    </label>
</div>