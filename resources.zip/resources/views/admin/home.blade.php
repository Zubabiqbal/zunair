@extends('admin_layouts.master')
@section('content')
@endsection